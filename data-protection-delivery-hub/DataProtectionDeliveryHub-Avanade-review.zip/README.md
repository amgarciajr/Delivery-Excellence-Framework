# Data Protection Delivery Hub

A Vibe-ready source and recreation package for a full-lifecycle Data Protection consulting delivery platform.

## Build intent
Create a reusable internal practice platform that standardizes opportunity handoff, engagement intake, discovery, assessment, scope, requirements, architecture, delivery, risk, decisions, testing, evidence, readiness, deliverables, handoff, operations, lessons learned, reusable assets, and practice intelligence.

## Safe deployment boundary
- Contains synthetic demonstration data only.
- Do not load client, personal, or production data until the target environment, connectors, security roles, data policies, ownership, support, and retention requirements are approved.
- AI suggestions are advisory. Human approval is required for architecture, legal/compliance conclusions, risk acceptance, readiness, and customer-facing outputs.

## Vibe use
1. Upload this ZIP as the source/recreation package if the Vibe experience accepts project ZIPs.
2. If ZIP upload is not available, attach `docs/VIBE_MASTER_PROMPT.md` and `data-model/full-data-model.json` as work content, then use the instruction at the top of the master prompt.
3. Keep the generated app in a solution named `DataProtectionDeliveryHub`.
4. Rebind target-environment connections and publish draft Dataverse tables only after review.

## Included
- Authoritative Vibe master prompt
- Full relational data model blueprint
- Role and security model
- Delivery stage gates
- Automation specifications
- Functional React/TypeScript app scaffold
- Synthetic seed data
- Acceptance tests and production-readiness checklist
